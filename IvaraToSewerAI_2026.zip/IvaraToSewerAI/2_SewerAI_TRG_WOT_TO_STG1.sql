create or replace TRIGGER TRG_WOT_TO_STG1
AFTER INSERT OR UPDATE OF
    wotasktitle,
    plndcompdate_dttm,
    plndstrtdate_dttm,
    workclassifi_oi
ON MNT.WORKORDERTASK
FOR EACH ROW
BEGIN
  MERGE INTO CUSTOMERDATA.EPSEWERAI_WOT_STG1 s
  USING (
    SELECT
      /* TASK_UUID is RAW(16) and NOT NULL in target table */
      :NEW.uuid               AS task_uuid,
      :NEW.wotasktitle        AS wotasktitle,
      :NEW.plndcompdate_dttm  AS plndcompdate_dttm,
      :NEW.plndstrtdate_dttm  AS plndstrtdate_dttm,
      :NEW.workclassifi_oi    AS workclassifi_oi
    FROM MNT.workorders wo
    WHERE wo.workordersoi = :NEW.workorder_oi
      AND wo.site_oi      = 58
      AND :NEW.workclassifi_oi IN (209, 211, 215, 266)
  ) src
  ON (s.task_uuid = src.task_uuid)

  WHEN MATCHED THEN
    UPDATE SET
      s.wotasktitle         = src.wotasktitle,
      s.plndcompdate_dttm   = src.plndcompdate_dttm,
      s.plndstrtdate_dttm   = src.plndstrtdate_dttm,
      s.workclassifi_oi     = src.workclassifi_oi,
      s.feed_status         = 'UPDATED'
    WHERE
          NVL(s.wotasktitle, '~') <> NVL(src.wotasktitle, '~')
       OR NVL(s.plndcompdate_dttm, DATE '1900-01-01')
          <> NVL(src.plndcompdate_dttm, DATE '1900-01-01')
       OR NVL(s.plndstrtdate_dttm, DATE '1900-01-01')
          <> NVL(src.plndstrtdate_dttm, DATE '1900-01-01')
       OR NVL(s.workclassifi_oi, -1)
          <> NVL(src.workclassifi_oi, -1)

  WHEN NOT MATCHED THEN
    INSERT (
      task_uuid,
      wotasktitle,
      plndcompdate_dttm,
      plndstrtdate_dttm,
      workclassifi_oi,
      feed_status
    )
    VALUES (
      src.task_uuid,
      src.wotasktitle,
      src.plndcompdate_dttm,
      src.plndstrtdate_dttm,
      src.workclassifi_oi,
      'NEW'
    );
END;