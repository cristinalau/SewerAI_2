------------------------------------------------------------
-- Step 1: Drop staging table if exists (CUSTOMERDATA)
------------------------------------------------------------

BEGIN
    EXECUTE IMMEDIATE 'DROP TABLE CUSTOMERDATA.EPSEWERAI_WOT_STG1';
EXCEPTION
    WHEN OTHERS THEN
        NULL; -- expected if first run
END;
/

------------------------------------------------------------
-- Step 2: Create staging table
------------------------------------------------------------
DROP TABLE CUSTOMERDATA.EPSEWERAI_WOT_STG1


CREATE TABLE CUSTOMERDATA.EPSEWERAI_WOT_STG1 (
    TASK_UUID           RAW(16)       NOT NULL,
    WOTASKTITLE         VARCHAR2(503),
    PLNDCOMPDATE_DTTM   DATE,
    PLNDSTRTDATE_DTTM   DATE,
    WORKCLASSIFI_OI     NUMBER,
    FEED_STATUS         VARCHAR2(50)
);
